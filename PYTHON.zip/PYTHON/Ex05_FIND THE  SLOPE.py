#FIND THE SLOPE - 18/06/26

x1=int(input("ENTER x1 Value :"))
y1=int(input("ENTER y1 Value :"))
x2=int(input("ENTER x2 Value :"))
y2=int(input("ENTER y2 Value :"))

slope=(y2-y1)/(x2-x1)

print("SLOPE OF TWO POINTS :",slope)
