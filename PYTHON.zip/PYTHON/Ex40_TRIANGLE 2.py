# TRIANGLE 2 - 09/07/26

n=int(input("ENTER n VALUE :"))

for i in range(1,n+1):
    for j in range(1,i+1):
        print(j,end="")
    print()
