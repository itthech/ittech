# GCD AND LCM OF TWO NUMBERS - 16/07/26

x=int(input("Enter First Number :"))
y=int(input("Enter Second Number :"))

gcd =0
lcm=0
if x<y:
    smaller=x
    greater=y
else:
    smaller=y
    greater=x

for i in range(1,smaller+1):
    if((x%i==0)and(y%i==0)):
        gcd=i

print("The GCD of ",x," and ",y," is ",gcd)

while True:
    if((greater%x==0)and(greater%y==0)):
        lcm=greater
        break
    greater+=1

print("The LCM of ",x," and ",y," is ",lcm)
