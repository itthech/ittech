# SUM OF SERIES 2+4+6+8+.....+n - 08/07/26

n=int(input("ENTER THE VALUE :"))
Sum=0
for i in range(2,n+1,2):
    Sum+=i

print("SUM OF SERIES 2+4+6+8+.....+n n=",n,":",Sum)
