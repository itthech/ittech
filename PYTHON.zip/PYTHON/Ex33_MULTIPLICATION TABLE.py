# MULTIPLICATION TABLE - 08/07/26

n=int(input("ENTER THE VALUE FOR MULTIPLICATION TABLE :"))

for i in range(1,20+1):
    print(i,"x",n,"=",i*n)
