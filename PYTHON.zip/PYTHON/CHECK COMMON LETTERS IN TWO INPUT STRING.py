# CHECK COMMON LETTERS IN TWO INPUT STRING- 24/07/26

s1=input("Enter String :")
s2=input("Enter String :")

a=str(set(s1)&set(s2))

print("The Common Letters are :",a)
