#SWAP TWO VALUES - 18/06/26
a=int(input("ENTER a Value :"))
b=int(input("ENTER b Value :"))

a,b=b,a

print("SWAPPED VALES :","a",a,"b",b)
