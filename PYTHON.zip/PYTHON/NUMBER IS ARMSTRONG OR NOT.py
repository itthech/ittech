#ARMSTRONG NUMBER OR NOT - 30/06/26

n=int(input("ENTER THE VALUE :"))
gnum=n
sum1=0
length=len(str(n))
while(n!=0):
    r = n%10
    sum1+=r**length
    n//=10

if( gnum == sum1):
    print("THE GIVEN NO. IS ARMSTRONG NUMBER !!!")
else :
    print("THE GIVEN NO. IS NOT A ARMSTRONG NUMBER !!!")
