#Area of Circle-18/06/26

r=float(input("ENTER Radius of Circle :"))

area=3.14*r**2

print("AREA OF CIRCLE :",area)
