# BOOK RETURN DAY - 25/06/26

day=int(input("ENTER THE NO. OF DAYS BOOK ISSUED : "))

maxlimit=5

print("MAXIMUM",maxlimit," DAYS ONLY ALLOW FOR RETURN THE BOOK")

if day <= maxlimit:
    print("THANK YOU FOR RETURNING THE BOOK BEFORE RETURN DATE !!!")
else :
    print("YOU DIDN'T RETURN THE BOOK BEFORE THE RETURN DATE , SO YOU ARE NEED TO PAY A FINE AMOUNT !!!")
    print("FINE AMOUNT RS : ",(day-maxlimit)*50)
