# SUM OF SERIES x^0+x^1+x^2+x^3+....+x^n - 09/07/26

n=int(input("ENTER n VALUE :"))
x=int(input("ENTER x VALUE :"))
Sum=0
for i in range(0,n+1):
    Sum+=x**i

print("SUM OF SERIES x^0+x^1+x^2+x^3+....+x^n n=",n,":",Sum)
