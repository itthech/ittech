# POWER CALCULATION - 08/07/26

x=int(input("ENTER x VALUE :"))
y=int(input("ENTER y VALUE :"))
p=1
for i in range(1,y+1):
    p=p*x

print(x,"power of ",y,":",p)
