#SUM OF INDIVIDUAL DIGIT - 30/06/26

n=int(input("ENTER THE VALUE :"))
sum1=0
while(n!=0):
    r = n%10
    sum1+=r
    n//=10

print("SUM OF INDIVIDUAL DIGIT :",sum1)
