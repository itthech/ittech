#ODD or EVEN - 18/06/26

a=int(input("ENTER a Value :"))

if(a==0):
    print("THE GIVEN NUMBER IS ZERO!!! ")
elif(a%2==0):
    print("THE GIVEN NUMBER IS EVEN !! ")
else:
    print("THE GIVEN NUMBER IS ODD !! ")
