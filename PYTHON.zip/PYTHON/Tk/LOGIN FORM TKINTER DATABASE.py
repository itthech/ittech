import sqlite3
conn = sqlite3.connect('data.db')
cursor = conn.cursor()
sql ="CREATE TABLE LOGIN(username CHAR(20) NOT NULL,password CHAR(20))"
cursor.execute(sql)
print("Table created successfully........")
conn.commit()

cursor.execute("INSERT INTO LOGIN VALUES('college','bhc')")
cursor.execute("INSERT INTO LOGIN VALUES('msc','it')")
conn.commit()

data=cursor.execute("SELECT * FROM LOGIN")
for row in data:
    print(row)
conn.close()



