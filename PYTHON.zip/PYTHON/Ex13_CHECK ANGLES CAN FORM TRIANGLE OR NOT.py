#THIS ANGLES FORM A TRIANGLE OR NOT - 25/06/26


a=int(input("Enter First Angle : "))
b=int(input("Enter Second Angle : "))
c=int(input("Enter Third Angle : "))

if a != 0 and b != 0 and c != 0 and a+b+c == 180:
    print(a,b,c,"THIS ANGLES CAN FORM A TRIANGLE !!! ")
else :
    print(a,b,c,"THIS ANGLES CAN'T FORM A TRIANGLE !!! ")
