# COS SERIES x^0/0!-x^2/2!+x^4/4!....+x^n/n! - 09/07/26

n=int(input("ENTER n VALUE :"))
x=int(input("ENTER x VALUE :"))
Sum=0
sign=1
for i in range(0,n+1,2):
    fact=1
    for j in range(1,i+1):
        fact=fact*j
    Sum+=sign*((x**i)/fact)
    sign*=-1

print("COS SERIES x^0/0!-x^2/2!+x^4/4!....+x^n/n! n=",n,":",Sum)
