# COUNT THE NUMBER OF LETTERS,DIGITS,SPECIAL CHARACTERS- 24/07/26

s=input("Enter String")
count1=0
count2=0
count3=0
for i in s:
    if(i.isalpha()):
        count1=count1+1
    elif(i.isdigit()):
        count2=count2+1
    else:
        count3=count3+1
print("The no of characters are:",count1)
print("The no of digits are:",count2)
print("The no of special characters are:",count3)
