# HANDLING MULTIPLE EXCEPTION - 01/08/26

import sys
ch=1
while ch<=6:
    ch=int(input("Enter the Choice :"))

    if ch==1:
        try:
            a=[10,20,30,40]
            print("Fifth Element :",a[4])
            
        except IndexError:
            print("An Index Error Occured !!!")

    elif ch==2:
        try:
            print("Unknown Variable :",x)
            
        except NameError:
            print("An Name Error Occured !!!")

    elif ch==3:
        try:
            c=12/0
            print("Divide by Zero :",c)
            
        except ZeroDivisionError:
            print("An Zero Division Error Occured !!!")

    elif ch==4:
        try:
            f=open("fakefile.txt","r")
            
        except IOError:
            print("A File Not Found Error Occured !!!")

    elif ch==5:
        try:
            import stud
            
        except ImportError:
            print("An Import Error Occured !!!")

    elif ch==6:
        sys.exit()

    else:
        print("Invald Choice !!!")
