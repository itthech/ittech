# EXCEPTION HANDLING CONTEXT- 01/08/26

try:
    d={"rno":101,"name":"MOHAN"}
    print("Element of Dictionary :",d["rn"])

except KeyError:
    print("KEY IS NOT PRESENTED !!!")

else:
    print("KEY to Display the Element !!!")

finally:
    print("End of the Program !!!")
