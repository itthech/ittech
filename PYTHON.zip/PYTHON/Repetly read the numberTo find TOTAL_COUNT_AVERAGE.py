#Repetly read the numberTo find TOTAL_COUNT_AVERAGE - 30/06/26
value=""
s=0
count=0
while (value != "Done"):
    value=input("ENTER THE VALUE :")
    s=s+int(value)
    count=count+1

print("TOTAL :",s,"COUNT :",count,"AVERAGE :",s/count)
