# UDP CLIENT - 03/09/26

import socket
client=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
saddr=("localhost",5000)
m="Hello Server !!!"

client.sendto(m.encode(),saddr)

d,addr=client.recvfrom(1024)
print("Message from Server :",d.decode())



client.close()
