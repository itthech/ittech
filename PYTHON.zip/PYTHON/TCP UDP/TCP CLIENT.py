# TCP CLIENT - 03/09/26

import socket
c=socket.socket()
host=socket.gethostname()
c.connect((host,3333))

print(c.recv(1024).decode())

c.send("Hello Server!!!".encode())
c.close()
