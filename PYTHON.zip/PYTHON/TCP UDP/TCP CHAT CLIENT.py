# TCP CHAT CLIENT - 03/09/26

import socket
c=socket.socket(socket.AF_INET,socket.SOCK_STREAM)

c.connect(("localhost",5000))
print("Connected To Server !!!")
while True:
    m=input("Client :")
    c.send(m.encode())
    if m.lower() == "bye":
        print("Chat Ended !!!")
        break
    reply=c.recv(1024).decode()
    print("SERVER :",reply)

    if reply.lower() == "bye":
        print("Chat Ended !!!")
        break
    
c.close()
