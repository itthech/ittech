# UDP SERVER - 03/09/26

import socket
server=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
server.bind(("localhost",5000))

print("UDP SERVER IS WAITING FOR MESSAGE !!!")
d,addr=server.recvfrom(1024)
print("Message from Client :",d.decode())

m="Hello Client, Message Received !!!"
server.sendto(m.encode(),addr)
server.close()
