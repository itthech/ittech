# FACTORIAL- 24/07/26

def fact(n):
    "Recursive function for factorial calculation"
    if(n==1):
        return(1)
    else:
        return(n*fact(n-1))
x=int(input("Enter the number"))
res=fact(x)
print("factorial:",x,"!",res)
    
