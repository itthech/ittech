#ADDITION OF THREE NUMBERS-18/06/26


a=int(input("Enter a Value :"))
b=int(input("Enter b Value :"))
c=int(input("Enter c Value :"))

print("ADDITION OF THREE NUMBER :",a+b+c)
