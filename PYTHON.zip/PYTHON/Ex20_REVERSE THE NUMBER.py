#REVERSE THE NUMBER - 30/06/26

n=int(input("ENTER THE VALUE :"))
rev=0
while(n!=0):
    r = n%10
    rev=rev*10+r
    n//=10

print("REVERSE THE NUMBER :",rev)
