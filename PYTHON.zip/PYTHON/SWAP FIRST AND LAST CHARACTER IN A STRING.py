# SWAP FIRST AND LAST CHARACTER IN A STRING- 24/07/26

s=input("Enter String :")
first=s[0]
last=s[-1]
middle=s[1:len(s)-1]
res=last+middle+first
print("MODIFIED STRING :",res)
