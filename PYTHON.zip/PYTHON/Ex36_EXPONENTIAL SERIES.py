# SUM OF SERIES x^0/0!+x^1/1!+x^2/2!+x^3/3!+....+x^n/n! - 09/07/26

n=int(input("ENTER n VALUE :"))
x=int(input("ENTER x VALUE :"))
Sum=0
for i in range(0,n+1):
    fact=1
    for j in range(1,i+1):
        fact=fact*j
    Sum+=(x**i)/fact

print("SUM OF SERIES x^0/0!+x^1/1!+x^2/2!+x^3/3!+....+x^n/n! n=",n,":",Sum)
