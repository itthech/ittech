# TRIANGLE 5 - 09/07/26

n=int(input("ENTER n VALUE :"))
space=20
for i in range(1,n+1):
    print(" "*space,end="   ")
    space=space-2
    for j in range(1,i+1):
        print(i,end="   ")
    print()

space+=4
for i in range(n-1,0,-1):
    print(" "*space,end="   ")
    for j in range(1,i+1):
        print(i,end="   ")
    space+=2
    print()
