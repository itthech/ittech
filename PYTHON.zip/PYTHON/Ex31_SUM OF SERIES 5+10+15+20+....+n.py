# SUM OF SERIES 5+10+15+20+....+n - 08/07/26

n=int(input("ENTER THE VALUE :"))
Sum=0
for i in range(5,n+1,5):
    Sum+=i

print("SUM OF SERIES 5+10+15+20+....+n n=",n,":",Sum)
