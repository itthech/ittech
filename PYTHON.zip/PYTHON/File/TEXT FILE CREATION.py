# TEXT FILE CREATION- 01/08/26

f1=open("file1.txt","w")
n=int(input("Enter No. of Records :"))
for i in range(n):
    s=input("Enter String :")
    f1.write(s+"\n")

f1.close()

f2=open("file1.txt","r")
print("\n")
print("DATA FROM THE FILE !!!")
print(f2.read())
f2.close
