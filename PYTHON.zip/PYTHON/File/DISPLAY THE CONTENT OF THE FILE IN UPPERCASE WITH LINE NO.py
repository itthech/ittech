# DISPLAY THE CONTENT OF THE FILE IN UPPERCASE WITH LINE NO- 01/08/26

fn=input("Enter Filename :")
lno=1
with open(fn,"r")as f:
    for line in f:
        print(str(lno)+"\t"+line.upper())
        lno+=1
        
