# DISPLAY THE CONTENT OF THE FILE IN REVERSE ORDER- 01/08/26

fn=input("Enter Filename :")
f1=open(fn,"r")
t=f1.read()
print("Original Content !!!")
print(t)
print("\n")
print("Reversed Content !!!")
revt="".join(reversed(t))
print(revt)
f1.close

