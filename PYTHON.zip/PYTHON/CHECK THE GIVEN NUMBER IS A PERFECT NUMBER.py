# CHECK THE GIVEN NUMBER IS A PERFECT NUMBER - 16/07/26

n=int(input("ENTER n VALUE :"))
Sum = 0
for i in range(1,n):
    if(n%i==0):
        Sum+=i

if(Sum==n):
    print("The Number is a Perfect Number !!!")
else:
    print("The Number is Not a Perfect Number !!!")
