#LARGEST AND SMALLEST OF THREE NUMBERS - 25/06/26

a=int(input("Enter a Value : "))
b=int(input("Enter b Value : "))
c=int(input("Enter c Value : "))

if a>b and a>c:
    large = a
elif b>c:
    large = b
else:
    large = c

if a<b and a<c:
    small = a
elif b<c:
    small = b
else:
    small = c

print(large," is a Largest Value ")
print(small," is a Smallest Value ")
