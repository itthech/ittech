# SQUARE - 16/07/26

n=int(input("ENTER n VALUE :"))
v=1
for i in range(1,n+1):
    for j in range(1,n+1):
        print(v,end=" ")
        v+=1
    print()
