# COMBINATION OF FOUR SINGLE DIGIT NUMBER - 16/07/26

a=int(input("ENTER a VALUE :"))
b=int(input("ENTER b VALUE :"))
c=int(input("ENTER c VALUE :"))
d=int(input("ENTER d VALUE :"))

list1=[]
list1.append(a)
list1.append(b)
list1.append(c)
list1.append(d)

for i in range(4):
    for j in range(4):
        for k in range(4):
            for l in range(4):
                if i != j and i != k and i != l and j != k and j != l and k != l:
                    print(list1[i],list1[j],list1[k],list1[l])
