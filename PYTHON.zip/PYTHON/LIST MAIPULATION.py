# LIST MAIPULATION - 07/08/26

import sys
class check:
    def __init__(self):
        self.n=[]

    def add(self,a):
        self.n.append(a)

    def delete(self,b):
        self.n.remove(b)

    def dis(self):
        return(self.n)

obj=check()
while True:
    print("1.ADD \n2.Delete \n3.Display \n4.Exit")
    ch=int(input("Enter Choice :"))
    if ch == 1:
        ele=int(input("Enter Element :"))
        obj.add(ele)
        print("Element Added !!!")
        print("List :",obj.dis())
        
    elif ch == 2:
        ele=int(input("Enter Element :"))
        obj.delete(ele)
        print("Element Deleted !!!")
        print("List :",obj.dis())
        
    elif ch == 3:
        print("List :",obj.dis())
        
    else:
        sys.exit()
