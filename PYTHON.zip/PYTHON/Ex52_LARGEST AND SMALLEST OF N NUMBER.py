# LARGEST AND SMALLEST OF N NUMBER - 17/07/26

n=int(input("Enter Number of Elements in a List :"))
lst=[]
for i in range(n):
    x=int(input("Enter The Value of x :"))
    lst.append(x)

large=lst[0]
small=lst[0]
for i in range(1,n):
    if lst[i]>large:
        large=lst[i]
        
    if lst[i]<small:
        small=lst[i]

print("Largest Value :",large,"\nSmallest Value :",small)
