class A:
    def input1(self):
        self.a = int(input("Enter the value: "))
class B:
    def input2(self):
        self.b = int(input("Enter the value: "))
class C(A, B):
    def process(self):
        self.c = self.a + self.b

    def display(self):
        print("a:", self.a)
        print("b:", self.b)
        print("c:", self.c)
ob = C()
ob.input1()
ob.input2()
ob.process()
ob.display()
