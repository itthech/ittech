# SET OPERATIONS - 17/07/26

lst1=[]
lst2=[]
n1=int(input("Enter Number of Elements in a List 1 :"))
for i in range(n1):
    x=int(input("Enter The Value of x :"))
    lst1.append(x)
n2=int(input("Enter Number of Elements in a List 2 :"))
for i in range(n2):
    x=int(input("Enter The Value of x :"))
    lst2.append(x)

s1=set(lst1)
s2=set(lst2)

print("The Union of two sets :",s1|s2)
print("The Intersection of two sets :",s1&s2)
print("The Difference of two sets :",s1-s2)
print("The Symmetric Difference of two sets :",s1^s2)
