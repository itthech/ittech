# SUM OF SERIES 1+3+5+7+....+n - 08/07/26

n=int(input("ENTER THE VALUE :"))
Sum=0
for i in range(1,n+1,2):
    Sum+=i

print("SUM OF SERIES 1+3+5+7+....+n n=",n,":",Sum)
