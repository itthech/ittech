#CHECK THREE SUBJECT MARKS - 25/06/26

english=int(input("ENTER ENGLISH MARK : "))
maths=int(input("ENTER MATHS MARK : "))
science=int(input("ENTER SCIENCE MARK : "))

print("AVERAGE OF MARKS :",(english+maths+science)/3)

if (english > 90):
    print("ENGLISH MARK : ",english)

if (maths > 90):
    print("MATHS MARK : ",maths)

if (science > 90):
    print("SCIENCE MARK : ",science)
