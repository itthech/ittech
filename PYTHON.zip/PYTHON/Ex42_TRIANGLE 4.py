# TRIANGLE 4 - 09/07/26

n=int(input("ENTER n VALUE :"))
space=20
for i in range(1,n+1):
    print(" "*space,end="   ")
    
    for j in range(1,i+1):
        print(i,end="   ")
    space=space-2
    print()
