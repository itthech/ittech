# SUM OF SERIES x1+x2+x3+....+xn - 08/07/26

n=int(input("ENTER THE VALUE :"))
Sum=0
for i in range(1,n+1):
    x=int(input("ENTER THE VALUE :"))
    Sum+=x

print("SUM OF SERIES x1+x2+x3+....+xn n=",n,":",Sum)
