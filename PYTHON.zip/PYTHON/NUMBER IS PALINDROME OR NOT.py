#NUMBER IS PALINDROME OR NOT - 30/06/26

n=int(input("ENTER THE VALUE :"))
gnum=n
rev=0
while(n!=0):
    r = n%10
    rev=rev*10+r
    n//=10

if (gnum==rev):
    print("THE GIVEN NUMBER IS PALINDROME !!!")
else :
    print("THE GIVEN NUMBER IS NOT A PALINDROME !!!")
