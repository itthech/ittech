# PASSWORD IS VALID OR NOT - 03/09/26

import re
password = input("Enter the Password :")
flag = 0
if len(password)<6 or len(password)>20:
    flag = -1

elif not re.search("[a-z]",password):
    flag = -1

elif not re.search("[A-Z]",password):
    flag = -1

elif not re.search("[0-9]",password):
    flag = -1

elif not re.search("[^a-zA-Z0-9]",password):
    flag = -1

elif  re.search("\s",password):
    flag = -1

else:
    flag = 0
    print(" Valid Password !!!")


if flag == -1:
    print("Not a Valid Password !!!")
