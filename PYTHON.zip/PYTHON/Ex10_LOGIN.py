#LOGIN - 18/06/26

username=input("ENTER USERNAME :")
password=input("ENTER PASSWORD :")

if(username=="it255215121" and password=="mohanraj"):
    print("LOGINNED SUCCESSFUL !!!")
else:
    print("INVALID USERNAME OR PASSWORD !!!")
