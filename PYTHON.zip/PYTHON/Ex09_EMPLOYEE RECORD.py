# EMPLOYEE RECORD - 18/06/26

empcode=input("ENTER EMPLOYEE CODE :")
name=input("ENTER EMPLOYEE NAME :")
salary=int(input("ENTER EMPLOYEE SALARY :"))
position=""

if(salary > 10000):
    position="MANAGER"
elif(salary >=5000 and salary <= 10000):
    position="CLERK"
else:
    position="EMPLOYEE"

print("WELCOME",position,name.upper(),"\nEMPLOYEE CODE :",empcode,"\nSALARY :",salary)
