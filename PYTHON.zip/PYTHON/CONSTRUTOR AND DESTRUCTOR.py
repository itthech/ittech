# CONSTRUTOR AND DESTRUCTOR - 07/08/26

class emp:
    def __init__(self,na,s):
        self.name=na
        self.sal=s

    def __init__(self):
        self.name="MOHAN"
        self.sa=10000

    def __del__(self):
        print("EMP Object Deleted !!!")

    def display(self):
        print("Name :",self.name)
        print("Salary :",self.sa)

e=emp()
e.display()
del(e)
