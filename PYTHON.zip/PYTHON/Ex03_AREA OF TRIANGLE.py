#AREA OF TRIANGLE - 18/06/26

a=float(input("ENTER a Value :"))
b=float(input("ENTER b Value :"))
c=float(input("ENTER c Value :"))

s=(a+b+c)/2

area=(s*(s-a)*(s-b)*(s-c))**0.5

print("S :",s,"AREA OF TRIANGLE :",area)
