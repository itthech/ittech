#ARITHMETIC OPERATIONS USING IF-ELIF-ELSE - 25/06/26

import sys
a=int(input("Enter a Value : "))
b=int(input("Enter b Value : "))

while True:
    c=int(input("Enter the Choice : "))
    if(c == 1):
        print("ADDITION :",a+b)

    elif(c == 2):
        print("SUBSTRACTION :",a-b)

    elif(c == 3):
        print("MULTIPLICATION :",a*b)

    elif(c == 4):
        print("DIVISION :",a/b)

    elif(c == 5):
        print("FLOOR DIVISION :",a//b)

    elif(c == 6):
        print("EXPONENTIATION :",a**b)

    elif(c == 7):
        print("MODULUS :",a%b)

    elif(c == 8):
        print("THANK YOU FOR YOUR ATTENTION !!!")
        sys.exit()
    else :
        print("INVALID CHOICE PLEASE ENTER CORRECT CHOICE !!!")
