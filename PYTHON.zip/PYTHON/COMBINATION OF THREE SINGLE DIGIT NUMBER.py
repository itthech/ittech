# COMBINATION OF THREE SINGLE DIGIT NUMBER - 16/07/26

a=int(input("ENTER a VALUE :"))
b=int(input("ENTER b VALUE :"))
c=int(input("ENTER c VALUE :"))

list1=[]
list1.append(a)
list1.append(b)
list1.append(c)

for i in range(3):
    for j in range(3):
        for k in range(3):
            if i != j and j != k and k != i:
                print(list1[i],list1[j],list1[k])
