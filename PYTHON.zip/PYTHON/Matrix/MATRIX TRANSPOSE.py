# MATRIX TRANSPOSE- 17/07/26

lst=[]
n=int(input("Enter No. of rows :"))
m=int(input("Enter No. of columns :"))
for i in range(m):
    lst.append([])
    for j in range(n):
        x=int(input("Enter Element :"))
        lst[i].append(x)

print("Given Matrix :")
for i in lst:
    print(i)

trans=[]
for i in range(n):
    trans.append([])
    for j in range(m):
        trans[i].append(lst[j][i])

print("Transpose Matrix :")
for i in trans:
    print(i)
