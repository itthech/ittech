# SUM OF ELEMENTS IN THE MATRIX- 17/07/26

lst=[]
n=int(input("Enter No. of rows :"))
m=int(input("Enter No. of columns :"))
for i in range(m):
    lst.append([])
    for j in range(n):
        x=int(input("Enter Element :"))
        lst[i].append(x)

print("Given Matrix :")
for i in lst:
    print(i)

Sum=0
for i in range(m):
    for j in range(n):
        Sum+=lst[i][j]

print("Sum OF Elements in Matrix :",Sum)