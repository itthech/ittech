# SUM OF SERIES 1+2+3+4+5+.....+n - 08/07/26

n=int(input("ENTER THE VALUE :"))
Sum=0
for i in range(1,n+1):
    Sum+=i

print("SUM OF SERIES 1+2+3+....+n n=",n,":",Sum)
