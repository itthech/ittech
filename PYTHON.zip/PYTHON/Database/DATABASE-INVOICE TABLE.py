import sqlite3

conn = sqlite3.connect("ex1.db")
cursor = conn.cursor()

choice = 1

while choice <= 5:
    choice = int(input("\nEnter your choice: "))

    if choice == 1:
        sql = '''
        CREATE TABLE IF NOT EXISTS inv1(
            pr_no INTEGER NOT NULL,
            pr_name CHAR(20),
            qty INTEGER,
            ut_pr FLOAT,
            amt FLOAT
        )
        '''
        cursor.execute(sql)
        print("Table created successfully")
        conn.commit()

    elif choice == 2:
        n = int(input("Enter number of records: "))

        for i in range(n):
            pr_no = int(input("Enter product no: "))
            pr_name = input("Enter product name: ")
            qty = int(input("Enter quantity: "))
            ut_pr = float(input("Enter unit price: "))

            sql = '''
            INSERT INTO inv1(pr_no, pr_name, qty, ut_pr)
            VALUES (?, ?, ?, ?)
            '''
            data = (pr_no, pr_name, qty, ut_pr)

            cursor.execute(sql, data)

        conn.commit()
        print("Records inserted successfully...")

    elif choice == 3:
        rec = cursor.execute("SELECT * FROM inv1")

        for row in rec:
            print(row)

    elif choice == 4:
        rec = cursor.execute("SELECT * FROM inv1")

        for row in rec:
            pr_no = row[0]
            qty = row[2]
            ut_pr = row[3]

            # Amount = Quantity × Unit Price
            amt = qty * ut_pr

            sql = "UPDATE inv1 SET amt = ? WHERE pr_no = ?"
            cursor.execute(sql, (amt, pr_no))

        conn.commit()
        print("Records updated successfully")

    elif choice == 5:
        no = int(input("Enter product number to be deleted: "))

        sql = "DELETE FROM inv1 WHERE pr_no = ?"
        cursor.execute(sql, (no,))

        conn.commit()
        print("Record deleted successfully")

    else:
        print("Invalid choice")

conn.close()
