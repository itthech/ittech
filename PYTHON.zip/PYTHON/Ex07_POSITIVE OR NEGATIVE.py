#POSITIVE or NEGATIVE - 18/06/26

a=int(input("ENTER a Value :"))

if(a==0):
    print("THE GIVEN NUMBER IS ZERO!!! ")
elif(a>=0):
    print("THE GIVEN NUMBER IS POSITIVE !! ")
else:
    print("THE GIVEN NUMBER IS NEGATIVE !! ")
