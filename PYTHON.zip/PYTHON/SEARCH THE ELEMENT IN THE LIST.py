# SEARCH THE ELEMENT IN THE LIST - 17/07/26

n=int(input("Enter Number of Elements in a List :"))
lst=[]
for i in range(n):
    x=int(input("Enter The Value of x :"))
    lst.append(x)

s=int(input("Enter the value to Search :"))
flag=0
for i in range(n):
    if(lst[i]==s):
        flag=1
        break
    
if flag==1:
    print("Present in position of :",i)
else :
    print("Not Present ")
