#LEAP YEAR - 18/06/26

year =int(input("ENTER  THE YEAR :"))

if(year%4==0 and year%100!=0):
    print(year,"THIS IS A LEAP YEAR !!!")
elif(year%400==0):
    print(year,"THIS IS A LEAP YEAR !!!")
elif(year%100==0):
    print(year,"THIS IS NOT A LEAP YEAR !!!")
else:
    print(year,"THIS IS NOT A LEAP YEAR !!!")
