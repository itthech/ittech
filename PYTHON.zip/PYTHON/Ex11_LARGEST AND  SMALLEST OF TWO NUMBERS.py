#LARGEST AND SMALLEST OF TWO NUMBERS - 25/06/26

a=int(input("Enter a Value : "))
b=int(input("Enter b Value : "))

if a>b:
    print(a,"is a Largest Value ")
    print(b,"is a Smallest Value ")
else:
    print(b,"is a Largest Value ")
    print(a,"is a Smallest Value ")
